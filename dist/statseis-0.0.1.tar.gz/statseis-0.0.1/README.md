This module is a work in progress.
This module contains functions to statistically analyse seismicity (source parameters e.g. time, location, and magnitude).
Package for importing, processing, and standardising earthquake source parameter data;
selecting mainshocks using the FET, MDET, and DDET methods;
identifying foreshocks using the BP, G-IET, and ESR methods.
Many functions require the renaming of earthquake catalog dataframe columns to: ID, MAGNITUDE, DATETIME, LON, LAT, DEPTH.